#ifndef EX9_H
#define EX9_H

// int sobreescreve_dado (FILE*, DADO);
void ex9(int*);

#endif