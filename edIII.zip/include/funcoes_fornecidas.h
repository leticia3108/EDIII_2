// Header para funções fornecidas

#ifndef FUNCOES_FORNECIDAS_H
#define FUNCOES_FORNECIDAS_H

#include <stdlib.h>
#include <stdio.h>

long converteNome (char*);
void my_scan(char*str);

#endif