#ifndef EX2_H
#define EX2_H

void ex2();

#endif