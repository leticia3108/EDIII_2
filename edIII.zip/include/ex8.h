#ifndef EX8_H
#define EX8_H

void ex8();

#endif