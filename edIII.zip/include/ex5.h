#ifndef EX5_H
#define EX5_H

void ex5();

#endif