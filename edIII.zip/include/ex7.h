#ifndef EX7_H
#define EX7_H

void cabecalho_indice(FILE*, FILE*);
int encontra_nome(FILE*, char*, indice*);
void ex7();

#endif